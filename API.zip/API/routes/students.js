const express = require('express');
const router = express.Router();
const studentschema  = require('../models/student')

router.get('/', async(req,res) => {
    try {
        const students = await studentschema.find();
        res.send(students);
    } catch (error) {
        res.send.json({message: error.message});
    }
});


router.get('/:id', (req,res) => {
    
});
router.post('/', async(req,res) => {
    const student = new studentschema({
        name: req.body.name,
        depatment: req.body.department,
        prn: req.body.prn,
    })

    try {
        const addstud = await student.save();
        res.json(addstud)
    } catch (error) {
        res.send.json({message: error.message});
        
    }
});
router.patch('/:id', (req,res) => {
    
});

router.delete('/:id', (req,res) => {
    
});

module.exports = router;