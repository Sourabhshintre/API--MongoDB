const mongoose = require('mongoose');

const studentschema = new mongoose.Schema({
    name:{
        type: String,
        required: true
    },
    depatment:{
        type: String,
        required: true
    },
    prn:{
        type: String,
        required: true
    },
});


module.exports = mongoose.model('student', studentschema);