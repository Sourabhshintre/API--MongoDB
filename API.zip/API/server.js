const express = require('express');
const app = express();
const mongoose = require('mongoose');

mongoose.connect('mongodb://0.0.0.0:27017/students' , {useNewURLParser: true});
const db = mongoose.connection;

db.on('error', (e) => {console.log(e)});
db.once('open', ()=>{console.log("Connected to database!!")});

app.use(express.json());

const studentrouter = require('./routes/students');

app.use('/student', studentrouter);


app.listen(3000, ()=>{
    console.log("server connected!!");
})